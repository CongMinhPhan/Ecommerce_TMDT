import React from 'react'

const UpdateAddress = () => {
  return (
    <div>UpdateAddress</div>
  )
}

export default UpdateAddress